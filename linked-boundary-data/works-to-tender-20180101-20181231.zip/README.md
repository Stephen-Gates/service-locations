Works to tender—1 January 2018 to 31 December 2018

This data set comprises construction contracts valued at $1m and above intended to be procured over the forward 12 month period.

Timing and contract values listed are indicative only and subject to full tender processes. Additional project numbers can be found in the notes section.
